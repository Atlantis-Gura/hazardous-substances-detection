## ArduinoHttpClient 0.4.0 - 2019.04.09

* Added URLEncoder helper

## ArduinoHttpClient 0.3.2 - 2019.02.04

* Changed Flush return value resulting in compilation error. Thanks @forGGe

## ArduinoHttpClient 0.3.1 - 2017.09.25

* Changed examples to support Arduino Create secret tabs
* Increase WebSocket secret-key length to 24 characters

## ArduinoHttpClient 0.3.0 - 2017.04.20

* Added support for PATCH operations
* Added support for chunked response bodies
* Added new beginBody API

## ArduinoHttpClient 0.2.0 - 2017.01.12

* Added PATCH method
* Added basic auth example
* Added custom header example

## ArduinoHttpClient 0.1.1 - 2016.12.16

* More robust response parser

## ArduinoHttpClient 0.1.0 - 2016.07.05

* Initial release

